# KaamSetu (Phase 1 — Test APK)

Hyperlocal home-service platform, MVP scaffold. Nexora Technologies.

## Stack
Kotlin, Jetpack Compose, Material 3, Navigation Compose, Room, MVVM + Repository pattern.
No backend yet — Room is seeded with demo data on first launch (see `SeedData.kt`).

## Opening in Android Studio
1. Open this folder as a project (Android Studio will generate `local.properties`
   and the Gradle wrapper jar itself — they're intentionally not committed).
2. Let Gradle sync (uses AGP 8.5.2 / Kotlin 1.9.24 / compileSdk 34 / minSdk 24).
3. Run the `app` configuration on an emulator or device.

## Flow
Splash → Role Selection → Customer / Technician / Admin, each with its own
bottom-nav tab set as described in the project brief.

## Privacy rule enforced in code
`JobRequest.publicView()` (see `domain/model/Models.kt`) is the only thing a
technician can see before being selected — it deliberately has no phone number
or exact address fields. `JobRepository.observeOpenRequestsPublicView()` is the
only stream technicians read from until `selectTechnician()` is called.

## Gradle Wrapper
`gradlew`, `gradlew.bat`, and `gradle/wrapper/gradle-wrapper.properties` are
committed, pinned to **Gradle 8.7** (the correct match for AGP 8.5.2 + Kotlin
1.9.24 + JDK 17). `gradle/wrapper/gradle-wrapper.jar` is a compiled binary and
is intentionally **not** committed here — hand-authoring binary bytes isn't
safe, and a corrupted jar breaks the build worse than a missing one. Two ways
to get it:
- **Android Studio**: open the project and sync — Studio downloads/repairs the
  wrapper jar automatically.
- **Command line**: if you have any Gradle install locally, run
  `gradle wrapper --gradle-version 8.7 --distribution-type bin` once from the
  project root; it writes a real, verified jar matching the properties file.

## CI
`.github/workflows/android.yml` builds `assembleDebug` on every push/PR to
`main` and uploads the APK as a workflow artifact named `kaamsetu-debug-apk`.
It first runs `gradle wrapper --gradle-version 8.7 --distribution-type bin`
(via the runner's system Gradle, provisioned by `gradle/actions/setup-gradle`)
to generate an authentic `gradle-wrapper.jar` from the committed properties
file, then builds with `./gradlew assembleDebug` as normal.

## What's intentionally NOT in Phase 1
AI assistant, photo/video upload, live GPS tracking, payment gateway, real
OTP/backend auth, price-change-request flow. See the project's architecture
notes for the full now-vs-later split.
